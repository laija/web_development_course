import { ResaltadoDirective } from './resaltado.directive';

describe('ResaltadoDirective', () => {
  it('should create an instance', () => {
    const directive = new ResaltadoDirective();
    expect(directive).toBeTruthy();
  });
});
